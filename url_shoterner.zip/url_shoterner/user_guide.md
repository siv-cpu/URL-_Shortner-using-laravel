URL Shortner Project
-----Working Flow----

* check .env file include correct db configration
* create a db.
* create a table in db using db migration
* create a column 
* create a view file
* do you want attach style your view file. public/assets/file.css 
    (Note:public diectory tha request ku entry point.anga tha js,image,css file ah store    pannuvom.)
* route create pannanum.
    ( Note : laravel validation rules to know in the document [Available validaton rules (topic name)]).
* form to be submit.so create a post route
* note: laravel validator path illuminate/support/facade kulla irukum
    * validator have static function (make)
 
 * redirect nu oru function um irukku and redirect class um iruku   
        * redirected class use panna path use pannanu               
        (illuminate/support/facade)
        * redirect class la oru to() static function irruku.
* str class enthukuna string function ah support panra class
    random() method iruuku. values= numeric
