<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{url('assets/style.css')}}">
    <title>URL Shortner</title>
</head>
<body>
    <div id="container">
        <h2>URL SHORTNER</h2>
        @if(Session::has('errors'))
            <h3 class="error">{{$errors->first('link')}}</h3>
        @endif
        @if(Session::has('message'))
            <h3 class="error">{{Session::get('message')}}</h3>
        @endif

        <!-- namma oruvakuna shorturl la kamikirathuku -->
        @if(Session::has('link'))
            <h3 class="error"><a href="{{url(Session::get('link'))}}">{{url(Session::get('link'))}}</a> This your short URL...</h3>
        @endif
        <form action="{{url('/')}}" method="post">
        @csrf
            <input type="text" name="link" placeholder="Insert your URL here and Press Enter!!!!!">
        </form>
    </div>    
</body>
</html>