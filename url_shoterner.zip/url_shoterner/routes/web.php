<?php

use App\Models\Link;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/',function (){
    return view('form');
});

//form submittion post route

Route::post('/',function(Request $request){
    //laravel have inbuild web application rules 
    $rules = array(
        'link' => 'required|url',
    );

    //validation process
    $validation = Validator::make($request->all(),$rules);

    if ($validation->fails()) {
       return Redirect::to('/')->withErrors($validation);
    }else{
        $link = Link::where('url',$request->input('link'))->first();

        // form la irrunthu vara data la hash irruntha tha if la la redirect pannrom hash value vaa...no hash..so should be created new hash in else part...
        if ($link) {
            return Redirect::to('/')->with('link',$link->hash);
            //short panna url hash link..ithu tha front la pogu...form ku...
        }else {
            do {
              $newHash = Str::random(6);  
              //first use satement include,
            } while (Link::where('hash',$newHash)->count()>0);  //itha condition la already $newhash la irruka value db la irukanu check panrom,


            //new ah oru data va create panna
            Link::create(array( //create a use panrathunalla model intha 2 field ah yu fillable a vaikanu...go to model
                'url' => $request->input('link'),
                'hash' => $newHash

            ));
            return Redirect::to('/')->with('link',$newHash);
        }
    }
    //known do-while condition.the while condition stasfied agura varakikum intha do statment run agu...

    
});



//short url la access pannum pohtu seriyana url ku poga...
    //step: 1.hash value ah va parameter la vangitu...athoda value ah function la vangikanu.. 
Route::get('{hash}',function($hash){
    //2.$hash value ah vachu link kana data va eduka..
    $link = Link::where('hash',$hash)->first();

    if ($link) {
        return Redirect::to($link->url); //intha redirect vara hash value ah vachu tha  url ku send pannu... 
    }else {
        return Redirect::to('/')->with('message','invaild Link');

    }
});