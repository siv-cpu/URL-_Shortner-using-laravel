<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(url('assets/style.css')); ?>">
    <title>URL Shortner</title>
</head>
<body>
    <div id="container">
        <h2>URL SHORTNER</h2>
        <?php if(Session::has('errors')): ?>
            <h3 class="error"><?php echo e($errors->first('link')); ?></h3>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
            <h3 class="error"><?php echo e(Session::get('message')); ?></h3>
        <?php endif; ?>

        <!-- namma oruvakuna shorturl la kamikirathuku -->
        <?php if(Session::has('link')): ?>
            <h3 class="error"><a href="<?php echo e(url(Session::get('link'))); ?>"><?php echo e(url(Session::get('link'))); ?></a> This your short URL...</h3>
        <?php endif; ?>
        <form action="<?php echo e(url('/')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <input type="text" name="link" placeholder="Insert your URL here and Press Enter!!!!!">
        </form>
    </div>    
</body>
</html><?php /**PATH D:\Siva\url_shoterner\resources\views/form.blade.php ENDPATH**/ ?>